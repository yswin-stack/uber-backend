/**
 * Shared type definitions used by both the backend and frontend.  These
 * declarations are intentionally lightweight; they describe the core
 * domain models without prescribing any storage or transport details.  By
 * colocating them in the `shared` folder we enable both the server and
 * client projects to import the same definitions without duplicating
 * code.  Please extend these types as new fields become necessary, but
 * avoid renaming existing properties to preserve backwards‑compatibility.
 */

// User roles within the system.  Additional roles can be appended
// transparently provided they are string literals.
export type UserRole = "admin" | "driver" | "rider";

// Possible states that a ride may occupy through its lifecycle.  See
// backend/services or shared/constants for transition rules.
export type RideStatus =
  | "scheduled"
  | "driver_en_route"
  | "arrived"
  | "in_progress"
  | "completed"
  | "cancelled_by_user"
  | "cancelled_by_driver"
  | "cancelled_by_admin";

// Subscription status values.  These reflect the state of a user’s plan.
export type SubscriptionStatus =
  | "pending"
  | "active"
  | "paused"
  | "cancelled";

// Codes identifying the available plans.  New plans can be introduced by
// adding additional string literals here and seeding them in the DB.
export type PlanCode = "premium" | "standard" | "light";

/**
 * Minimal ride record returned from the API.  For detailed ride
 * information see {@link RideWithDetails}.
 */
export interface Ride {
  id: number;
  user_id: number;
  driver_id?: number | null;
  pickup_time: string; // ISO timestamp in UTC
  dropoff_time?: string | null; // ISO timestamp in UTC
  is_grocery: boolean;
  status: RideStatus;
}

/**
 * Extended ride record that includes descriptive fields useful to
 * front‑end clients.  Some properties may be optional depending on
 * whether they’ve been provided at booking time or populated later.
 */
export interface RideWithDetails extends Ride {
  pickup_address: string;
  pickup_lat: number;
  pickup_lng: number;
  dropoff_address: string;
  dropoff_lat: number;
  dropoff_lng: number;
  notes?: string | null;
}

/**
 * Summary of a user’s ride credits for the current billing period.  The
 * `*_total` fields represent the allowance and the `*_used` fields track
 * consumption.
 */
export interface CreditsSummary {
  standard_total: number;
  standard_used: number;
  grocery_total: number;
  grocery_used: number;
}

/**
 * Representation of an active or historical subscription.  Dates are
 * expressed as ISO strings in UTC.  The `notes` field can contain free
 * text associated with the plan (e.g. referral codes, special cases).
 */
export interface Subscription {
  id: number;
  user_id: number;
  plan_code: PlanCode;
  status: SubscriptionStatus;
  current_period_start: string;
  current_period_end: string;
  payment_method: string;
  notes?: string | null;
}

/**
 * A weekly schedule template describes a user’s commuting pattern.  Each
 * record represents either a commute to work or back home on a given
 * weekday.  Times should be stored in ISO 24‑hour "HH:MM" format and
 * interpreted in the application’s local timezone (see shared/constants).
 */
export interface ScheduleTemplate {
  id: number;
  user_id: number;
  day_of_week: number; // 0 = Monday, 6 = Sunday
  type: "to_work" | "from_work";
  desired_arrival_time: string; // e.g. "08:50"
  flex_minutes: number;
}

/**
 * Standard API success wrapper.  When a request completes successfully
 * the server should respond with `{ ok: true, data: … }` where `data`
 * contains the requested payload.
 */
export interface ApiSuccess<T> {
  ok: true;
  data: T;
}

/**
 * Standard API error wrapper.  When a request fails the server should
 * respond with `{ ok: false, code, message }`.  The `code` field should
 * be a short machine‑readable identifier and `message` should be
 * human‑friendly.
 */
export interface ApiError {
  ok: false;
  code: string;
  message: string;
}

/**
 * Discriminated union of API responses.  Clients can switch on the
 * `ok` property to determine whether a request succeeded and then
 * handle the `data` or `message` accordingly.
 */
export type ApiResponse<T> = ApiSuccess<T> | ApiError;
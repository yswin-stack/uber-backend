/**
 * Shared application constants.  These values are imported by both the
 * backend and frontend to ensure that business rules such as time
 * windows and enums remain consistent across the stack.  If you need
 * to introduce new constants or modify existing values please do so
 * here rather than scattering magic numbers throughout the codebase.
 */

// Timezone used for all local operations.  All timestamps stored in
// the database are in UTC, but when converting to/from the user’s
// perspective this zone should be respected.  See also src/lib/time.ts.
export const APP_TIMEZONE = "America/Winnipeg";

// Peak service windows during which only certain plans are allowed to
// schedule rides.  Each window is expressed in 24‑hour "HH:MM" format
// relative to the local timezone.  Actual enforcement is implemented in
// later backend steps.
export const PEAK_WINDOWS = {
  morning: { start: "07:00", end: "10:00" },
  evening: { start: "16:00", end: "18:00" },
} as const;

// Route constants.  While not strictly necessary, defining API paths
// centrally reduces the risk of typos and makes it easier to update
// endpoints in the future.  Feel free to extend this object as new
// routes are introduced.
export const API_ROUTES = {
  auth: {
    login: "/auth/login",
    register: "/auth/register",
  },
  rides: {
    base: "/rides",
  },
  plans: {
    base: "/plans",
  },
} as const;

// Enum‑like re‑exports for convenience.  These definitions mirror the
// string unions declared in shared/types.ts.  Importing from this
// module can provide IDE auto‑completion when using values rather than
// types.
export const USER_ROLES = {
  admin: "admin",
  driver: "driver",
  rider: "rider",
} as const;

export const RIDE_STATUSES = {
  scheduled: "scheduled",
  driver_en_route: "driver_en_route",
  arrived: "arrived",
  in_progress: "in_progress",
  completed: "completed",
  cancelled_by_user: "cancelled_by_user",
  cancelled_by_driver: "cancelled_by_driver",
  cancelled_by_admin: "cancelled_by_admin",
} as const;

export const SUBSCRIPTION_STATUSES = {
  pending: "pending",
  active: "active",
  paused: "paused",
  cancelled: "cancelled",
} as const;

export const PLAN_CODES = {
  premium: "premium",
  standard: "standard",
  light: "light",
} as const;

// The allowed payment method strings for subscriptions.  When new
// payment methods are supported they should be added here.
export const PAYMENT_METHODS = {
  cash: "cash",
  card_placeholder: "card_placeholder",
  apple_pay_placeholder: "apple_pay_placeholder",
} as const;
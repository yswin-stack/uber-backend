import type { ApiError, ApiSuccess } from "../../shared/types";

/**
 * Helper function to wrap successful responses in the standard API
 * envelope.  Use this helper when returning data from your routes to
 * ensure consistent shape across the application.  You must still set
 * the appropriate HTTP status code on the Express response object
 * yourself.
 *
 * @param data The payload to return to the client.
 */
export function ok<T>(data: T): ApiSuccess<T> {
  return { ok: true, data };
}

/**
 * Helper function to wrap error responses in the standard API envelope.
 * Use this helper when responding to client errors or internal
 * exceptions.  You must still set the appropriate HTTP status code on
 * the Express response object yourself.
 *
 * @param code A machine‑readable identifier for the error.
 * @param message A human‑friendly description of the error.
 */
export function fail(code: string, message: string): ApiError {
  return { ok: false, code, message };
}
import { APP_TIMEZONE } from "../../shared/constants";

/**
 * Convert a Date into a UTC ISO string (without milliseconds).  This
 * helper should be used whenever persisting timestamps to the
 * database.  We deliberately drop milliseconds because most SQL
 * schemas store timestamps without fractional seconds, and
 * truncating them here avoids surprises.
 *
 * @param date The Date instance to convert.
 */
export function toUtcIso(date: Date): string {
  // Use toISOString() which always returns in UTC and then strip
  // milliseconds for consistency (YYYY‑MM‑DDTHH:mm:ssZ).
  return date.toISOString().replace(/\.\d{3}Z$/, "Z");
}

/**
 * Parse an ISO timestamp string (in UTC) into a Date.  This helper
 * exists primarily for symmetry with {@link toUtcIso}.  If the input
 * cannot be parsed, the returned Date will be invalid (check
 * isNaN(date.getTime())).
 *
 * @param isoString A date/time string in ISO 8601 format.
 */
export function parseUtc(isoString: string): Date {
  return new Date(isoString);
}

/**
 * Convert a local Date (in the application’s timezone) to a UTC ISO
 * string.  Node.js does not natively support arbitrary timezone
 * conversions without external libraries; therefore this function
 * approximates the conversion by constructing an ISO string as if the
 * provided Date represented a wall clock time in the local timezone.
 * This is sufficient for our current needs but may need to be
 * revisited if more complex time arithmetic is required.
 *
 * @param date The local Date to convert.
 * @param timeZone Optional override of the application timezone.
 */
export function localToUtc(date: Date, timeZone: string = APP_TIMEZONE): string {
  // Format the local date in the target timezone and then parse as
  // though it were UTC.  The Intl API provides formatting but not
  // parsing, so this is a best‑effort approach.
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  const parts = formatter.formatToParts(date).reduce<Record<string, string>>((acc, p) => {
    if (p.type !== "literal") acc[p.type] = p.value;
    return acc;
  }, {});
  const { year, month, day, hour, minute, second } = parts;
  const iso = `${year}-${month}-${day}T${hour}:${minute}:${second}Z`;
  return iso;
}

/**
 * Convert a UTC ISO timestamp into a Date representing local time in
 * the application’s timezone.  Without a full timezone library this
 * function simply returns a JavaScript Date constructed from the
 * original string, which is interpreted in UTC.  Consumers should use
 * Intl.DateTimeFormat with a `timeZone` option when presenting the
 * Date to users.
 *
 * @param isoString A UTC ISO timestamp.
 * @param timeZone Optional override of the application timezone.
 */
export function utcToLocal(isoString: string, timeZone: string = APP_TIMEZONE): Date {
  // Parsing into a Date will always interpret the string as UTC.  To
  // present it in the desired timezone, UI layers should use
  // Intl.DateTimeFormat with the provided timeZone.
  return new Date(isoString);
}